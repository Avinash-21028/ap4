<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="ground" tilewidth="30" tileheight="30" tilecount="900" columns="45">
 <image source="ground.png" width="1350" height="619"/>
</tileset>
