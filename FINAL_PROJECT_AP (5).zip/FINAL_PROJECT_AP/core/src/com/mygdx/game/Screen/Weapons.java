package com.mygdx.game.Screen;

public class Weapons {

}
